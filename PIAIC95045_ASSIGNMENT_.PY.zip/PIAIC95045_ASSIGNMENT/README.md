# PIAICAssignments
Artificial Intelligence (AI) Assignments From PIAIC 

## Assignments of AI
1. [Numpy Assignment 1](https://github.com/Anonster/PIAICAssignments/blob/main/PIAIC149723Assignment%231(Numpy%20Fundamentals).ipynb)
2. [Numpy Assignment 2](https://github.com/Anonster/PIAICAssignments/blob/main/PIAIC149723Assignment%232(NumpyFundamentals).ipynb)
